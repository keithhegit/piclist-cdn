# RECEIVE-ON-WINDOWS.md — 本地 Codex 接收步骤

交接分支：`feat/uiux-quick-capture`  
交接完整 SHA：`dbf9e3d91e3c710c3f796a4f39eaa2365b50d757`  
main（不动）：`61ac40895e8829a8d798d824b5c3554f488503fd`  
远程（脱敏）：`https://github.com/keithhegit/life-is-data`  
HK 冻结时间：2026-10-18 15:47:33 CST。HK 会保持冻结，不清理源目录。

先读：`Docs/codex-handoff/00-START-HERE.md`，再读 05、06，最后读 ENVIRONMENT / BRANCHES / UNFINISHED / TEST-EVIDENCE。

## 禁止事项（全程有效）

- 不合 main、不 push（任何分支）、不部署、不改 Cloudflare 开关/Access、不删测试数据。
- 不用 `reset --hard`、`git clean`、强制切换；不删除旧文件（只允许下面第 0 步的整目录改名）。
- **旧目录里的 `ubuntu-ssh.txt` 等凭据文件不要读、不要复制。**
- 不要改 `D:\Codex_workspace\.git`（见第 0 步）。
- 不改全局 Node / 系统 PATH / 全局执行策略；不 `setx`。
- 不打印 `OWNER_ACTOR_ID` 值（已跟踪在 wrangler 配置里）、token、cookie。

## 交接包放置

把 zip 解压到仓库外的 **`D:\Codex_workspace\_handoff-staging\`**（如：`D:\Codex_workspace\_handoff-staging\life-is-data-codex-transfer-20261018\`）。不要解压进 `D:\Codex_workspace\life-is-data`。

## 第 0 步：处理现有非仓库目录（Keith 已批准，由本地 Codex 执行）

现状（由 Keith 侧在 2026-10-18 15:49 CST 测得）：`D:\Codex_workspace\life-is-data` **不是 git 仓库**，里面是旧交接资料（`Docs\Plan`、`handoff-dots-grok`、`build-node24-ubuntu-HK`、`cloudflare-update-20261015`、`islandfishing-webgpu-followup-2026-10-15`、嵌套旧仓库 `life-is-data-local-review-20261014-197ea4b` 等），共 **1065 个文件 / 10978190 字节**。

1. **只读检查 `D:\Codex_workspace\.git`**：它存在，但 git 认为那里不是仓库。只看，不修复、不删除、不初始化。并确认后续 git 命令都用 `-C <明确路径>`，不会被这个 `.git` 影响。
2. **确认没有进程锁着文件**：之前 `Rename-Item` 因文件被占用失败过。先关掉打开该目录的编辑器/终端/资源管理器/索引进程（如 VS Code、Explorer 窗口、在该目录下的 shell）。不要强杀不明进程；查不清就停下报告。
3. 改名前记录基线：
   ```powershell
   $old = 'D:\Codex_workspace\life-is-data'
   $legacy = 'D:\Codex_workspace\life-is-data-legacy-20261018'
   $items = Get-ChildItem -LiteralPath $old -Recurse -Force -File
   $items.Count; ($items | Measure-Object Length -Sum).Sum   # 应为 1065 / 10978190；不一致先报告
   ```
4. **只有 `$legacy` 不存在时**才改名；存在就停下报告：
   ```powershell
   if (-not (Test-Path -LiteralPath $legacy)) { Rename-Item -LiteralPath $old -NewName 'life-is-data-legacy-20261018' } else { 'STOP: legacy exists' }
   ```
   只做整目录 `Rename-Item`。**不删除、不复制后删除。** 改名失败就停下，不重试其他方式。
5. 校验：对 `$legacy` 重新计数和求和，必须等于第 3 步的数字（1065 / 10978190）；然后确认 `Test-Path -LiteralPath $old` 为 False。
6. 改名过程中不要打开或读取 `ubuntu-ssh.txt` 等凭据文件（只计数/计大小，不读内容）。

## 第 1 步：核对交接包哈希

在 `D:\Codex_workspace\_handoff-staging\life-is-data-codex-transfer-20261018\` 下，逐行核对 `TRANSFER-MANIFEST.sha256`（格式：`sha256  字节数  相对路径`）：

```powershell
$root = 'D:\Codex_workspace\_handoff-staging\life-is-data-codex-transfer-20261018'
Get-Content -LiteralPath "$root\TRANSFER-MANIFEST.sha256" -Encoding UTF8 | Where-Object { $_ -and -not $_.StartsWith('#') } | ForEach-Object {
  $h, $n, $p = $_ -split '  ', 3
  $f = Join-Path $root $p
  if (-not (Test-Path -LiteralPath $f)) { "MISSING $p" }
  else {
    $ok = ((Get-FileHash -Algorithm SHA256 -LiteralPath $f).Hash.ToLower() -eq $h) -and ((Get-Item -LiteralPath $f).Length -eq [int64]$n)
    if (-not $ok) { "MISMATCH $p" }
  }
}
```
没有输出 = 全部匹配。有 MISSING/MISMATCH 就停下。Dots 原始文档也可以用 `DOCUMENTS-MANIFEST.sha256` 交叉核对（HK 侧核对已通过）。

## 第 2 步：建立代码根（二选一，目标此时必须不存在）

```powershell
$target = 'D:\Codex_workspace\life-is-data'
Test-Path -LiteralPath $target   # 必须是 False
git ls-remote https://github.com/keithhegit/life-is-data.git refs/heads/feat/uiux-quick-capture
```

A. **远端路线（首选）**：ls-remote 显示 `dbf9e3d91e3c710c3f796a4f39eaa2365b50d757` 时：
```powershell
git clone --branch feat/uiux-quick-capture https://github.com/keithhegit/life-is-data.git $target
```

B. **bundle 路线**（无法访问 GitHub 或远端 SHA 不同时）：
```powershell
$bundle = "$root\code\life-is-data-feat-uiux-quick-capture.bundle"
git bundle list-heads $bundle   # 应为：dbf9e3d91e3c710c3f796a4f39eaa2365b50d757 refs/heads/feat/uiux-quick-capture
git clone --branch feat/uiux-quick-capture $bundle $target
git -C $target bundle verify $bundle
```
bundle 是用分支名导出的（不是 `--all`），完整历史，单一 head，clone 后在该分支上，不是 detached HEAD。

两条路线都要做：
```powershell
git -C $target rev-parse HEAD            # 必须 = dbf9e3d91e3c710c3f796a4f39eaa2365b50d757
git -C $target branch --show-current     # feat/uiux-quick-capture
git -C $target status --short --branch   # 干净
```
clone 报错时不要删除重试，先报告。

**补丁 / 未跟踪文件：无。** HK 工作区干净，没有 staged.patch / unstaged.patch / untracked/。

## 第 3 步：合入交接文档

仓库跟踪的是**小写 `docs/`**，没有 `Docs/`，也没有已跟踪的 `docs/codex-handoff/`。把交接包 `Docs\codex-handoff\` 的内容复制到 **`$target\docs\codex-handoff\`**（不要新建大写 `Docs`；目标存在同名文件就停下）：
```powershell
$dst = "$target\docs\codex-handoff"
if (Test-Path -LiteralPath $dst) { 'STOP: exists' } else { Copy-Item -LiteralPath "$root\Docs\codex-handoff" -Destination $dst -Recurse }
git -C $target status --short    # 应只多出 docs/codex-handoff/（未跟踪）；先不提交
```
是否提交这些文档由 Keith 决定；接管前不要 push。

## 第 4 步：环境（见 ENVIRONMENT.md 和 06 §2–§4）

- Win11 全局 Node 是 **v22.12.0**，不满足 `>=24.19.0 <25`。需要隔离的 **Node 24.19.0**，只改当前 PowerShell 会话的 PATH。**来源由 Keith 决定**；没有就报告缺失，不要自己下载。
- 在新 clone 里按锁安装：先根目录 `npm ci`，再 `cd cloudflare; npm ci`（cloudflare 的测试依赖根 node_modules）。安装前后对比 `git status --short`。不要用 `npm install` 改锁，不运行 audit fix，不全局装 wrangler。
- `better-sqlite3` 原生模块编译失败 → 记为阻塞并报告，不改依赖。
- 核验：`cd cloudflare; npm run check`。HK 基线：exit 0，backend 18/144，UI 9/69。
- 不跑 `test:e2e`（要远端 + Access）；不跑 `scripts/release-pages.sh`；截图夹具 `shoot.mjs` 写死了 Linux 路径，Windows 上预计失败，只记录，不修改。
- 结果写进 `docs\codex-handoff\TEST-EVIDENCE.md`（追加 Windows 段落），格式见 06 §4。

## 第 5 步：接管回执

按 05 §6 填写回执，交给 Keith。只有 Keith 明确说“确认接管”后，Windows Codex 才成为唯一写入者。在此之前只做接收核验。
