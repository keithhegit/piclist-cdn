# 05 Ubuntu 交出与 Windows 接收

这是待执行说明：编写时没有连接两台机器、核验仓库或迁移文件。Ubuntu 正由外部 Grok agent 操作；Windows 未连接且未授权执行。下列操作由持有本机权限的 agent 执行，不确定时停止。

## 1. 边界

- 仓库：https://github.com/keithhegit/life-is-data 。目标 `D:\Codex_workspace\life-is-data`，不能假定为空或是仓库根。
- 历史报告 main=`61ac408`，`feat/uiux-quick-capture` HEAD=`dbf9e3d`。均须 Ubuntu 核实当前值及完整 SHA；不宣称已是最新。
- 仅交接和核验，不合 main、不 push、不部署。禁止覆盖旧文件、`reset --hard`、`git clean`、强制切换。
- 若仓库既有 `docs`，沿用 `docs/codex-handoff`；Windows 通常可通过 `Docs` 访问。不要新增仅大小写不同的第二目录或强行改名。若两者同时存在，停止并提出保留文件的整理方案。

## 2. Ubuntu 冻结与盘点

完成当前原子操作后，停止该项目的代码写入、自动修复和提交，记录冻结时间。后续仅整理交接资料，所有变化纳入最终清单。在已知候选目录进行只读检查：

```bash
pwd
git rev-parse --show-toplevel
git rev-parse --git-dir
git status --short --branch
git branch --show-current
git rev-parse HEAD
git branch -vv
git diff --stat
git diff --cached --stat
git ls-files --others --exclude-standard
git ls-files | grep -E '^(Docs|docs)/' | head -40
```

根目录不符或不是仓库，先定位，不写入。`.git` 可能是 worktree 指针文件。避免记录含 token 的 remote URL、环境变量或终端历史。

如需核验远端，确认 origin 是上述仓库后可 `git fetch origin`，单独记录抓取时间和引用变化；不要 pull/merge/rebase。记录本地 HEAD 与远端差异。没抓取就写“远端最新状态未核验”。

## 3. 最小交付包

复用已有说明或明确章节引用，避免重复创建资料：

- `ENVIRONMENT.md`：按 06 记录版本证据、锁文件、真实 scripts、变量名及启动条件。
- `BRANCHES.md`：冻结时间、当前分支/完整 HEAD、实际 main SHA、远端核验时间、是否 detached HEAD。
- `UNFINISHED.md`：未完成事项、风险、暂存/未暂存/未跟踪文件、迁移项和应用顺序；无则写“无”。
- `TEST-EVIDENCE.md`：实际命令、时间、SHA、退出码、结果；未运行或失败如实记录。
- `TRANSFER-MANIFEST.sha256`：最终交付文件相对路径及 SHA-256，另记字节数；清单不包含自身。

禁止传输真实 `.env` 值、tokens、密码、私钥、npm 认证或 Cloudflare 登录态。可以提供已检查无真实值的 `.env.example`。不复制 Linux node_modules、系统安装目录或用户目录缓存。忽略文件中必要的非秘密资料应逐项判断，不可整包复制。

### 代码二选一

A. **已有最新远端分支**：Ubuntu 确认交接完整 SHA 已可从受权远端获取，Windows fetch 接收。交接不授权新增 push；未提交更改仍单独交付。

B. **Git bundle**：先审查选定提交的可达历史，确认无秘密；bundle 包含历史，不能只看工作区。不要 `--all` 顺带导出无关分支。发现秘密即停止，不自行改写历史。以下写入命令仅在审查后使用，暂存目录应在仓库外且获准，输出文件存在即停止：

```bash
git bundle create '<受权暂存目录>/life-is-data.bundle' HEAD
git bundle verify '<受权暂存目录>/life-is-data.bundle'
git bundle list-heads '<受权暂存目录>/life-is-data.bundle'
# 审查差异（包括删除行）无秘密，且输出文件不存在后：
git diff --cached --binary > '<受权暂存目录>/staged.patch'
git diff --binary > '<受权暂存目录>/unstaged.patch'
```

未跟踪文件不在补丁中，审查后逐项复制到独立 `untracked/`，保留相对路径并记清单。不能迁移的改动必须列为阻塞。定稿后，对实际交付的明确文件列表运行 `sha256sum`，生成清单；不要用包含清单自身的通配符。修改后重新生成。哈希只证明字节一致，清单也须通过可信渠道交付。

## 4. 传输不是写一个 D 盘路径

Linux 写 `D:\Codex_workspace\life-is-data` 不会自动落到 Windows。仅用 Ubuntu 已有、用户授权且实际连通的通道，把整个交接包传到 Windows 仓库外独立暂存目录，不直接覆盖项目。核对接收机器、路径与结果。先确立或安全同步代码根，再按仓库既有大小写合入 Docs/codex-handoff；若先把 Docs 解压进空目标，clone 会因非空失败，不能因此删除 Docs 或旧文件。

没有通道时，把受控交付包交给用户下载，再交本地 Codex 接收。不要临时开放共享、上传公开链接、配置 token/SSH key 或创建持久访问。接收端确实读到文件后才能说“已到 Windows”。

## 5. Windows 接收门禁

先只读检查；非空、嵌套仓库、根路径不符或已有改动，停止创建/应用，让本地 agent 提出并确认备份、并存方案。不能因表面没有 `.git` 就删除旧目录。

```powershell
$target = 'D:\Codex_workspace\life-is-data'
Test-Path -LiteralPath $target
if (Test-Path -LiteralPath $target) {
  Get-ChildItem -LiteralPath $target -Force
  git -C $target rev-parse --show-toplevel
  git -C $target rev-parse --git-dir
  git -C $target status --short --branch
}
Get-FileHash -Algorithm SHA256 -LiteralPath '<接收文件>'
```

逐个核对清单，缺失或哈希不符即停止。bundle 先用 `git bundle list-heads '<bundle路径>'` 核对导出完整 SHA。`git bundle verify` 需要有效 Git 仓库上下文，应在已有安全仓库中执行，或在下面 clone 成功后执行，不在任意目录运行，也不为此初始化旧目录。仅当目标不存在或确认空目录，才二选一创建；报错时不删除旧文件重试：

```powershell
git clone --branch feat/uiux-quick-capture https://github.com/keithhegit/life-is-data.git $target
# 或（HEAD 导出的 bundle 可能产生 detached HEAD）：
git clone '<已核验bundle完整路径>' $target
# bundle 路线 clone 成功后：
git -C $target bundle verify '<已核验bundle完整路径>'
git -C $target rev-parse HEAD
```

已有正确仓库先检查和 fetch，不直接在脏工作区切换。新干净副本中用 `git rev-parse HEAD` 核对交接完整 SHA。需要换到其他提交时，先确定不覆盖现有工作的方案。

仅应用已审查、清单中存在的补丁：先 `git apply --check --index staged.patch`，通过后 `git apply --index staged.patch`；再 `git apply --check unstaged.patch`，通过后 `git apply unstaged.patch`。使用实际完整路径。任何失败即停，不强制应用。未跟踪文件仅在同名目标不存在时放入。再按 06 核验环境。

## 6. 接管回执

```text
接管时间 / 实际仓库根：
当前分支 / 完整 HEAD SHA：
文件与哈希：全部匹配 / 缺失或不符项
补丁和未跟踪文件：已接收 / 未接收项
实际 Node/npm/lockfile：见 ENVIRONMENT.md
安装、启动、测试结果及未运行项：见 TEST-EVIDENCE.md
阻塞与下一步：
单一写入者：Windows Codex / 尚未接管
结论：确认接管 / 暂不确认
```

Windows 确认前只做接收核验；Ubuntu 保持冻结和可答疑，不退出、不清理源目录。收到明确“确认接管”后 Ubuntu 停止该项目操作，保留源目录与交付包。阻塞未解时交接未完成，双方先约定单一写入者再修复。接管不等于所有测试通过或已经发布。
