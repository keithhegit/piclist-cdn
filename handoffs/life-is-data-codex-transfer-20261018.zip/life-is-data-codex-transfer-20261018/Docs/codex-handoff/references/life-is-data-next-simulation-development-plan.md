# life-is-data 用户模拟闭环 Implementation Plan

**Goal：** 下一轮交付后，Keith 可以直接在 dot 聊天或手机 WebApp 记录一段虚构信息，由 dot 完成实际读取、分析、写回，并让 Keith 在网页看到依据、补充信息、选择方案和复盘结果。

**Architecture：** 保留现有 Cloudflare Pages → Records Worker → Durable Objects 存储以及 owner Access。复用 capture、修订、分析队列和不可变结果；新增明确的 TEST 批次及受保护的人工操作入口。dot 通过自己的已登录云浏览器操作，不接入站内模型 provider，不假设存在聊天 webhook 或后台唤醒能力。

**Tech Stack：** 现有 Node / TypeScript、React、Cloudflare Pages、Workers、Durable Objects；Ubuntu 沿用仓库锁定的 Node、npm、Wrangler 版本。

**Spec：** 本文件包含本轮产品规格、接口变更提案、实施步骤及发布条件；配套用户测试清单另附。涉及新路径和字段均为待开发合同，不代表线上已存在。

日期：2026-10-17，新加坡时间。接收方：Ubuntu 开发 agent。交付目标：可开始共同模拟测试的真实运行版本，不是原型、静态 UI 或仅通过单元测试的代码包。

## 0. 先读结论

1. G1 已证明人工领取、分析写回和读回的技术路径；收尾后的测试能力已关闭。不能直接把旧 harness 当成日常产品入口继续使用。
2. 本轮只建立“有明确 TEST 标签的文字模拟闭环”，并完成一次有后续结果的决策复盘。保持 `real_data_allowed=false`。
3. WebApp 仍是轻量录入和查阅入口；dot 仍是唯一分析入口。用户不必复制 JSON、填写租约、打开控制台或管理任务编号。
4. 下一轮发布前，Ubuntu 必须完成真实浏览器端到端冒烟，再交给 dot + Keith 验收。程序测试通过、构建 Active、页面打开都不能代替这一条。
5. 小时处理、09:00 自动简报、即时唤醒、照片持久化识别、正式真实资料开放不作为这轮承诺。不能为了看起来完整而用假状态填充。

## 1. 当前基线与证据等级

### 1.1 已由 dot 实际观察

2026-10-17 19:55–19:56 新加坡时间，在 dot 云浏览器登录态下：

- `/api/session` 返回 JSON、`owner:true`。
- `analysis_harness:false`、`dot_manual_synthetic:false`、`real_data_allowed:false`。
- `dot_channel:false`、`dot_event_channel:false`、`chat_ingestion:false`、`jobs:false`、`digests:false`。
- 手动合成联调面板显示关闭，不再提供领取、提交控件。
- 既有两条测试分析结果仍可读，状态保持 current / analyzed；没有因关闭开关而删除。
- 复核是 GET 和页面读取，没有再次写入，也没有独立探测全部后端拒绝路径。

### 1.2 Ubuntu 汇报，作为发布基线待仓库核对

- main：`8b5f3aa`；Pages：`8b61b36d`。
- Records Worker：`35295ea8`，100% 流量。
- Worker `ANALYSIS_HARNESS`、`DOT_MANUAL_SYNTHETIC` 均 disabled；Pages 对应两个 secret 已删除并重建。
- 自动构建后仍保留关闭值，Ubuntu 隔三分钟复核；这是本次构建证据，不是所有未来部署永不漂移的保证。
- 已保留测试数据，未改真实资料开关。

### 1.3 开工前必须核对

- [ ] `git status` 干净、当前 main 的完整 SHA；若已晚于上述 SHA，先列差异再确定基线。
- [ ] 核对 UI/PWA 分支是否已有提交、是否合并、哪些测试实际运行。不能把“Cursor 已启动”当成 UI 已完成。
- [ ] 保存不含值的配置清单、当前资源版本与数据迁移版本。不要打印环境变量全集。
- [ ] 记录 G1 成功回执及关闭回执所在文档，不覆盖历史验收结果。

## 2. 全局约束

- 仅 owner Access 账号可访问；不增加 Everyone、Bypass、公开后门或长效共享密钥。
- 不新增 `/api/agent/*`，不建立第二套分析队列，不接 APILink / 其他模型 provider。
- 现有两个 harness 开关保持关闭。新产品模拟能力采用单独、明确命名的门禁，启用前由 Keith 确认具体范围。
- 所有新增模拟资料、回答、选择、结果和复盘都有服务端 TEST 批次归属。客户端标签不能成为唯一隔离依据。
- 测试内容不进入真实个人画像、统计、晨报事实或长期个人目标；运营项目进度仍是真实项目记录，不能混为模拟资料。
- 文字首轮；不要求用户先选领域、填完整日期或先建目标。
- 所有写入维持 owner 鉴权、同源校验、请求头校验、正文限额、幂等及乐观并发保护。
- 不改 `OWNER_ACTOR_ID`。它不是密码，但与数据定位相关；更换可能造成看似丢数据。对日志曝光先做最小化日志整改，不用轮换此标识来掩盖问题。
- 数据迁移编号从实际 main 接续；与备份/恢复工作协调，不预设下一号一定是 v3。
- 删除测试数据不是这一轮自动动作。先可导出、可恢复验证、展示清理范围，再取得当次确认。

## 3. 产品体验：用户真的如何开始

### 3.1 聊天录入

Keith 说：“记一下，模拟人物小蓝今天阅读 12 分钟。”

1. dot 按测试上下文识别为 TEST，保留原话。
2. dot 在已登录 WebApp 的 owner 模拟工作台中保存原文。可用原消息 ID 时一并保存引用；没有可用深链就保存来源类型、消息 ID 和录入时间，不编造链接。
3. 服务器返回 capture ID、批次、修订号后，dot 才说“已保存”；尚未操作或网络异常，只能说“已收到，尚未写入”。
4. dot 从服务器读回原文，领取其分析任务，写入自己的分析，再读回确认。
5. Keith 打开网页能看到同一条原文及结果，不需操作开发联调面板。

这条链路的自动化边界要清楚：本轮是 dot 在当前对话中主动操作浏览器，不是网站自动收到了所有聊天消息。`chat_ingestion` 继续 false；另以准确文案说明“由 dot 代录”。

### 3.2 网页录入

1. 首页显示“模拟测试中”，提供单手可用输入框和快捷预填按钮。
2. 一段文字提交后持久化到当前 TEST 批次；页面明确“已保存，待 dot 处理”。
3. “Dots分析”将当前修订入队。如果没有即时事件通道，显示“已排队；请回到 dot 聊天说‘处理待分析’”。不能显示“已通知 dot”。
4. dot 收到用户消息后，打开工作台处理。用户不需要复制原文或 JSON。
5. 刷新后可查看结果。页面不承诺“一小时内”，除非真实定时任务已经另外实现并验证。

### 3.3 补充、选择与复盘

- 分析有关键缺失信息时，最多呈现三个关键问题；不重要的信息允许留空。
- 用户补充是新证据，独立保存并关联原记录/分析；不能当成法律授权或“同意所有建议”。
- 用户决定选择某个选项后，记录“选择了什么、基于什么信息、准备何时复盘”；时间可空。
- 后续用户给结果，保存实际观察及来源，再生成复盘。分别呈现“当时决策过程是否合理”和“后来结果如何”，不因一次好结果自动断言原决策正确。
- 不把界面看过、问题答过、按钮点过误记成用户认可分析结论。

## 4. 数据和接口变更提案

以下是实施合同。Ubuntu 应先映射到当前真实类型和文件，确认兼容后冻结；已有等价接口优先扩展，不重复造轮子。

### 4.1 TEST 批次

新增 `SimulationBatch`：`id`、`label`、`status(active|closed)`、`created_at`、`closed_at`。服务端按 owner 存储，最多一个 active 批次。

所有新增模拟对象带 `simulation_batch_id` 和服务端固定 `data_class:test`。原始记录不靠正文含“测试”来判断。历史测试记录不全库自动迁移，按已确认 ID 清单补关联；不改变旧正文和版本。

建议接口：

- `POST /api/simulation/batches`：`{client_submit_id,label}`，创建/幂等返回批次。
- `GET /api/simulation/batches/current`：当前批次或 null。
- `POST /api/simulation/batches/:id/close`：只关闭新写入入口，不删除数据；带 expected_revision 或等价并发机制。
- `GET /api/simulation/batches/:id/export`：owner 鉴权 JSON 导出，包括原文、修订、分析、补充、决策、结果和关系；排除租约令牌、Cookie、JWT、内部配置。

服务端 gate 提案：`SIMULATION_MODE=enabled`。session 新增 `simulation_capture`、`simulation_operator`、`simulation_export`，按实际实现和配置返回。不要把全局 `export:true` 用于尚未实现的完整个人库导出。

### 4.2 原文和来源

复用 `/api/captures`、修订、分析入队和读回接口。为新写入显式增加、严格验证：

- `simulation_batch_id`：必须属于当前 owner 且 active。
- `source`：`{kind:web|dot_chat, message_id?:string, occurred_at?:ISO8601}`。记录服务器 received_at；用户事件时间未知时保留 null，不用上传时间填充。模拟剧情日期与服务器 received_at 分开保存；例如场景写 2026-11-02，不代表现实已发生，也不创建现实提醒。模拟复盘日期只在 TEST 批次内展示。

前端不允许任意传 owner 或 data_class；服务端根据认证及批次确定。旧请求形状保留现有行为，不把无批次请求默认为真实资料。本轮新增入口必须有批次。

正文仍按现有限额 4000；快捷按钮仅预填，提交一次幂等 ID 在结果不明时保持不变。同一用户动作重试用同一 ID；两次不同事件即使正文完全一样也分别保存，不能以内容哈希合并。消息 ID 的存在仅表示来源引用，不证明聊天系统自动认证了消息作者。用户原话与 dot 的摘要分别保存；多轮补充保留每条消息的来源，修订明确关联同一 capture，不把 dot 整理后的段落冒充用户原文。

### 4.3 产品操作入口

建立 owner 模拟工作台，与历史 G1 面板分开命名。它复用相同分析服务，不复制租约/冲突算法。

建议产品路由：

- `POST /api/analysis/operator/claim`：`{simulation_batch_id, request_id, lease_ms}`；首版明确选中一个任务再领取，避免旧队列任务抢占新测试。只有该批次、该修订、可领取任务能够返回。
- `POST /api/analysis/operator/submit`：沿用已冻结 submit 的业务字段白名单；服务器从任务核对批次，不相信客户端自报批次。固定来源标识建议 `dot-owner-assisted-test`，必须显示为人工触发测试。
- `GET /api/analysis/:id`：沿用现有读回。

新路由必须重新明确在 owner + simulation gate + 批次 gate 下可用，历史 harness 两开关不参与授权且仍关闭。若仓库已有产品 operator 路由，使用现有命名，不建立平行版本。不得将旧 harness “只有测试用所以检查宽松”逻辑照搬。

保持：租约不进 URL/日志/浏览器永久存储；完成结果不可变；相同提交可读回同一结果；不同结果不得静默覆盖；源修订变化使旧结果 stale；失败不能假报分析完成。

首版不提供用户可见的“故意失败”“冲突提交”按钮。技术回归测试在测试代码执行，真实浏览器只做有目的的产品链路。

### 4.4 补充、决定、结果

优先新增小型关系表/对象，避免把所有事件反复塞回分析摘要：

- `Clarification`：id、capture_id、analysis_id、question_index/问题原文、answer_text、source、batch_id、created_at。保留提出问题时的分析版本。
- `Decision`：id、title、selected_option_text、alternatives_snapshot、expectation_snapshot、basis_analysis_id、basis_capture_revision、reason?、review_due_at?、revision、batch_id。选择时冻结当时有哪些选项和预期（允许明确“未设定预期”），以后不能用实际结果倒填原预测。选择由用户确认后写入；dot 不替用户擅自选择。
- `Outcome`：id、decision_id、body、observed_at?、source、revision、batch_id、created_at；修订保留历史。
- `DecisionReview`：id、decision_id、decision_revision、outcome_refs（ID+revision+来源引用）、process_assessment、outcome_assessment、uncertainties、next_options、created_at、batch_id。固定所用决定和结果版本；后来修订不能静默改变旧复盘依据，应标过时并产生新复盘。明确为 dot 分析，非用户同意。

路由可按现有风格使用 `/api/captures/:id/clarifications`、`/api/decisions`、`/api/decisions/:id/outcomes`、`/api/decisions/:id/reviews`。所有新增写入带 client_submit_id，修订带 expected_revision。每个动作的请求/响应、错误码、白名单在 `docs/api/simulation-v1.md` 固化后再接 UI。

不扩展完整任务管理、复杂财务模型、医疗推荐、图表大屏或自动日历。这些不属于最小模拟闭环。

## 5. 文件责任和实施任务

文件名按当前仓库实际结构对齐，以下新文件名为建议；不要借本轮重构整个应用。

### M0：冻结基线和合同

文件：`docs/api/simulation-v1.md`、`docs/ops/simulation-release.md`、现有 session/contracts/schema 文件。

- [ ] 核对 main 和 UI 分支，列出需合并提交；建立 `feat/user-simulation-v1`。
- [ ] 写合同测试：旧 session 能力不变；harness 仍关闭；新增能力默认 false；未知字段拒绝。
- [ ] 确认新 gate 名称、TEST 批次语义、路由及 payload，记录数据迁移编号。
- [ ] 运行合同测试，保存命令和实际结果；提交独立 commit。

产物：所有开发者使用同一份接口合同，不再靠手写“正确 JSON”掩盖 UI 构造错误。

### M1：TEST 录入和导出

文件建议：`cloudflare/src/simulation.ts`、现有 record-store/schema/http/contracts、`cloudflare/tests/simulation.test.ts`、`web/cloudflare/api.ts`。

- [ ] 先写失败测试：无权限/开关关闭/批次不存在/批次关闭/跨批次归属拒绝；同幂等键重试只有一条。
- [ ] 实现批次、capture 元数据和来源；迁移保持旧记录不丢失。
- [ ] 实现批次 JSON 导出和结构校验；输出清单数量、schema_version、导出时间。
- [ ] 使用全新测试存储从导出恢复或导入验证，核对对象数、引用、正文和修订。没有验证恢复就不能称为可恢复备份。
- [ ] 实际 HTTP → Worker → DO 集成测试通过后提交。

产物：用户可保存和读回带明确 TEST 归属的原文；清理前具备可验证导出基础。

### M2：dot 可操作的产品工作台

文件建议：`web/cloudflare/SimulationWorkbench.tsx`、对应 test、api 客户端、共享分析服务与 operator 路由。

- [ ] 写失败测试：指定 request 领取、旧任务不误领、来源修改拒绝旧租约、空队列明确显示。
- [ ] 将租约/结果规则提取为共享业务函数，旧 harness 行为保持，不能复制出两个不同版本。
- [ ] 实现“选择记录 → 读取原文 → 领取 → 填摘要/事实/推断/选项/关键问题 → 提交 → 读回”UI。无须手填 JSON 或 token。
- [ ] 客户端真实 payload 构造函数直接用于 HTTP → DO 集成测试；覆盖本轮曾出现的字段白名单错误。
- [ ] 错误显示字段名和安全原因，不包含 token、owner内部ID或完整敏感正文。
- [ ] 完成后确认字段在刷新后可读，来源为人工测试；提交。

产物：dot 能依靠现有云浏览器完成操作，不需要尚不存在的 API 插件、事件通道或新凭据。

### M3：补充和最小决策复盘

文件建议：`cloudflare/src/decision-review.ts`、关联 store/http、`web/cloudflare/DecisionReview.tsx` 及对应测试。

- [ ] 写失败测试：回答不等于同意、修订不覆盖旧分析、重复点击不重复选择、无结果不能伪造已复盘。
- [ ] 实现补充记录及重新分析入口；来源版本变化显示旧结果待更新。
- [ ] 实现决定卡：必填只保留“决定什么、选择什么”，其他信息可后补。
- [ ] 实现实际结果录入和 dot 复盘写回；依据对象可点击查阅。
- [ ] 校验 TEST 批次贯穿全链路，新增结果不进入真实统计；提交。

产物：一个虚构决定能够被后续虚构结果复盘，且原始依据和过程可查。

### M4：移动首页及 PWA 外壳整合（基础可用必需；安装优化为 P1）

文件：现有 `web/cloudflare/App.tsx`、style、manifest/icons、已有 UI 分支实现及测试。

- [ ] 先审查 UI 分支差异再选择性合入，不覆盖鉴权、幂等、冲突处理。
- [ ] “今日 / 记录 / 复盘”入口；首页优先待补充/待复盘，缺日期显示未设置，不能算逾期。
- [ ] 单手可用 composer、快捷预填；清晰的保存/分析两行状态；手机键盘不挡提交。
- [ ] 加 manifest/icon 和桌面入口说明；不引入默认缓存私人 API 的 service worker。
- [ ] 移动浏览器 360/390 宽及桌面验收；横向无溢出，刷新结果仍在。

产物：可用的轻量手机页面。手机录入、查阅与刷新持久化属于 P0；PWA 安装细节和完整视觉换肤属于 P1，不得阻塞文字模拟首交付。安装桌面快捷方式不意味着离线同步、后台计算或推送已支持。

### M5：真实浏览器验收与发布

- [ ] 在本地或隔离的合成存储运行所有回归及迁移测试；列出未运行项，不隐藏历史基线失败。
- [ ] 生成发布包：提交 SHA、变化清单、测试命令、数据迁移、能力变化、回滚兼容性、配置变更清单。
- [ ] 由 Keith 确认新模拟门禁启用，保留 owner-only Access；两个旧 harness 开关保持关闭。
- [ ] 发布前完成 TEST 批次导出/导入回环验证，并保存代码与配置版本。该验证仅覆盖 TEST 批次，不声称全库备份可恢复；本轮只做加法迁移，任何破坏性迁移必须等完整备份恢复能力就绪。部署后读取 authenticated session，不能只检查构建绿色。
- [ ] Ubuntu 以虚构文字走完整真实浏览器链路，提供记录/请求/结果 ID 和刷新读回证据，不包含凭据。
- [ ] dot 使用自己的浏览器重复一次完整链路；Keith 再使用手机执行配套清单。三者的测试结论分别记录。

## 6. 验收门槛

验收分两个门槛，避免必须让用户测完才说能够开测。

**A：可以开始共同模拟测试**：Ubuntu 完成 M0–M3、基础手机可用性、下面前两条安全检查，并用自己浏览器实际跑完一条文字保存→分析写回→刷新读回；交付用户操作说明和未测项。达到 A 就应邀请 Keith 与 dot 开测，不等待 PWA 安装、完整视觉换肤或后续自动化。

**B：本轮最终验收通过**：Keith 与 dot 按清单完成下面全部相关项，才宣布产品模拟闭环验收通过：

- owner 登录可用，非 owner 无法读取或写入；未登录受 Access 保护。
- 新 TEST 能力确实启用；旧 harness 仍 false；real_data_allowed 仍 false。
- 聊天中的一条虚构文字由 dot 实际保存到服务器，并从网页读回。
- 网页的一条虚构文字可入队，由 dot 实际分析写回；刷新后不丢。
- 至少一个关键问题的补充、一次来源修订、一次选择与后续结果复盘真实持久化。
- 有测试批次清单和可验证导出；没有默认删库、没将测试数据污染真实资料。
- UI 不出现虚假的“已通知”“自动处理中”“已发日报”。
- 任一环节失败，交接必须写明失败位置、ID、响应码和安全的字段级错误，不用“差不多好了”代替证据。

通过标准是可复现的用户操作结果，不是测试数量。99/99、27/27 等旧结果只能作为历史记录，不能直接复用为新版本测试成绩。

## 7. dot 实际操作手册

1. 在自己的云浏览器打开生产站，读取 session，确认 owner、TEST 能力、真实资料禁止。
2. 打开当前批次，核对批次名称；新建测试资料时保留原消息原文，不擅自补写事实。
3. 保存并读回，记录 capture_id/revision；回执不明先查询，不重新生成幂等 ID盲目提交。
4. 选择同一 request，领取后读原文，按“来源记载 / 推断 / 选项 / 关键问题”填写。
5. 提交并读回；回执丢失先读结果，不重复生成不同答案写入。
6. 用户补充后保存新证据，再更新分析；用户选择后才创建决定。
7. 后续结果照原话保存；复盘明确哪些结论有依据、哪些仍未知。
8. 给用户短回复：实际保存了什么、还有什么关键问题、网页哪里可查。没有完成写入就明确说尚未保存。

若 cloud browser 下线或 Access 会话过期，停止写入并通知用户；不能通过提取 Cookie、复制 JWT 或开放公开接口绕过。

## 8. 发布、回滚和开关纪律

- `keep_vars:true` 不是关闭功能的方法。关闭必须明确设置对应值为 disabled，Pages 侧移除对应配置并重建，再 authenticated session 复核。
- 新模拟 gate 的配置变更记录只保留名称、是否配置和允许披露的布尔状态，不输出全部变量值。
- 回滚前先核对旧代码能否读新 schema。旧 Worker `b329db7a` 曾带开关开启，不能作为“安全关闭”的默认回滚点。
- 首选回滚到本轮发布前已确认关闭且兼容 schema 的版本；当前历史候选由 Ubuntu 核实，不在文档里保证某个旧版本永远兼容。
- 回滚后检查 Access、owner、能力开关、旧记录和 TEST 批次，不只检查首页能打开。
- 不在本轮自动删除历史数据。清理工具先 dry-run 列出 batch 与关联对象数量；保留非测试资料。永久删除需要 Keith 确认具体批次后执行。

## 9. 这轮明确延期的能力

| 能力 | 本轮处理 |
|---|---|
| 照片/文件 | `file_uploads=false` 时入口明确未开放；可在 dot 聊天讨论图片，但不能称为已保存到 WebApp。照片持久化、文件权限、原图索引与备份另一个里程碑。 |
| WebApp 内聊天模型 | 不做，不接 provider。 |
| 即时唤醒 dot | 当前事件通道不存在，按钮只排队并提示回聊天；保持相关能力 false。 |
| 每小时自动处理、09:00 自动简报 | 未实现不承诺。本轮人工调用，后续验证真实调度和发送去重后单独上线。 |
| 真实健康/财务等资料 | 保持禁止；模拟通过不自动开放。 |
| 完整离线编辑与同步 | 不做；PWA 不缓存私人数据，不假报离线已保存。 |
| 全库备份恢复 | 本轮至少 TEST 批次导出及测试恢复验证；不能把它表述为全库灾备已就绪。 |

## 10. Ubuntu 最终交付清单

- [ ] 可检出的代码分支及完整提交 SHA；合并/发布状态分开说明。
- [ ] API 合同、迁移说明、release/rollback runbook、脱敏配置变更清单。
- [ ] 自动化测试原始命令与摘要、真实浏览器端到端证据、手机未测项。
- [ ] 当前 production URL、Pages/Worker version、实际 session 能力布尔值。
- [ ] 一段用户能照做的开测说明：打开哪里、第一句说什么、预期看到什么。
- [ ] 配套模拟测试用例结果表，未执行项写“未执行”，不能预打通过。
- [ ] TEST 批次和导出文件，永久清理待确认。
- [ ] 剩余限制：无自动唤醒、无小时后台处理、无真实资料开放。

交接时首先回答：“是否达到 A 门槛，Keith 现在能否与 dot 开始文字模拟？”以 Ubuntu 最近一次真实浏览器闭环为依据；B 门槛则由共同测试完成后另行确认。如不能开测，给出具体阻塞步骤和所需修复，不把尚未跑通的基础集成留给用户自行调试。
