# U4 附件存储方案（计划 only）

> **状态：计划文档，未创建任何 Cloudflare 资源，未改运行代码的存储绑定。**  
> 本文只描述现状、拟议资源和 Keith 需明确批准的事项。

## 1. 当前状态

| 项 | 现状 |
| --- | --- |
| `CAPABILITIES.file_uploads` | 在 `cloudflare/src/http.ts` 硬编码为 `false` |
| 上传路由 | Cloudflare Worker / Pages 侧**无**附件 upload / stream 路由 |
| R2 / KV / D1 绑定 | 当前 Records Worker **无**附件用 R2/KV/D1 binding（以现有 `wrangler.worker.jsonc` 为准） |
| 平台本地模型 | `src/platform` 与 `web/src/offline` 仍保留**本地** attachment / upload 模型（SQLite / outbox），与 Cloudflare 试验部署未接通 |
| UI | U1 QuickCapture 的「拍照 / 上传」仅提示「附件录入尚未开放」，不打开文件选择器 |

## 2. 拟议 Cloudflare 资源（尚未创建）

| 资源 | 建议名（示例） | 访问 |
| --- | --- | --- |
| R2 bucket（preview） | `lid-attachments-preview` | 私有；**禁止** `r2.dev` 公共 URL；**禁止**自定义公开域名 |
| R2 bucket（production） | `lid-attachments-production` | 同上，私有 |

- **Bindings**：优先挂在 **Records Worker**（读写与 owner 校验同路径）。  
- **Pages**：默认**不**直接绑 R2；由 Pages → Worker `/api/*` 代理。若将来 Pages Function 需直写，需单独审批。  
- 不新建 KV/D1 专用于附件二进制；元数据进现有 Durable Object（见 schema）。

## 3. 拟议 API（加法，未实现）

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| `POST` | `/api/simulation/attachments` | 上传意图或 multipart（经 Pages→Worker）；绑定 `capture_id` + `simulation_batch_id`；幂等键 `client_submit_id` + `sha256` |
| `GET` | `/api/attachments/:id` | 私有流式读取；**必须** owner 校验；无公开直链 |

响应与错误码风格对齐现有 simulation / capture API；`real_data_allowed` 保持 `false` 时仅 `data_class=test`。

## 4. Schema（加法，拟 v5）

- DO 表 `attachments`（或等价）：`attachment_id`, `owner`, `capture_id`, `batch_id`, `sha256`, `content_type`, `byte_size`, `client_submit_id`, `created_at`, `linked_at`, `data_class`。  
- **Schema v5 加法**：只增表/列，不改现有 capture/decision 语义。  
- **回滚含义（类比 v4）**：回滚 Worker 必须能打开 v5 存储；勿用仍拒绝高版本的旧 Worker。禁用附件开关不等于删数据。

## 5. 类型、大小与处理

| 规则 | 建议 |
| --- | --- |
| 允许类型 | `image/jpeg`, `image/png`, `image/webp`, `image/heic`（若解码链就绪）, `application/pdf` |
| 单文件上限 | 例如 8 MiB（最终以批准值为准） |
| 每 capture / 批次总上限 | 例如 32 MiB |
| MIME | 服务端魔数嗅探；不信任客户端 `Content-Type` |
| EXIF / GPS | **默认剥离** GPS 与可识别位置 EXIF；保留方向信息需单独批准 |
| 能力开关 | 新能力键仍用 `file_uploads`，且要求 `SIMULATION_MODE` 打开 **并** 新增显式开关（名称待批，例如 `FILE_UPLOADS=enabled`） |
| 数据分级 | 首期仅 `TEST` / `data_class=test` |

## 6. 孤儿清理

- 定义：上传后 **N 小时**（建议 24h）未关联 `capture_id` 的对象。  
- **先 dry-run** 列出候选；**禁止**未经批准的自动删除。  
- 清理作业默认关闭，需运维显式触发。

## 7. 日志与读访问证据

- 日志**不得**包含文件正文或完整 base64。  
- 可记：`attachment_id`、`sha256` 前缀、`byte_size`、`content_type`、`batch_id`、结果码。  
- Dot / 分析通道若需读附件：单独记录 **read access evidence**（谁、何时、哪个 `attachment_id`），与现有 lease 证据风格一致。

## 8. 回滚

1. 关闭 `file_uploads` / 显式开关 → API 501/403，UI 保持「尚未开放」。  
2. R2 与 DO 元数据**保留**。  
3. Worker 保持对 v5 的打开兼容；回滚二进制须预先验证。

## 9. 成本（粗算，非正式报价）

- R2 存储 + Class A/B 操作；预览桶与生产桶分开以免测数据混入。  
- 出口流量：私有 Worker 流式回源，避免公共 CDN 缓存私人文件。  
- 具体预算表在批准范围后另附。

## 10. Keith 必须明确批准的事项

1. 是否创建 preview / production 两个**私有** R2 bucket（名称最终拍板）。  
2. 是否仅 Worker 绑定 R2（Pages 不直绑）。  
3. 显式开关名称与与 `SIMULATION_MODE` 的组合门闩。  
4. 允许 MIME 列表与大小上限。  
5. EXIF/GPS 剥离策略。  
6. Schema 升到 v5 的窗口与回滚 Worker 预检。  
7. 孤儿清理的 N 小时阈值，以及「dry-run 后人工批准再删」。  
8. 是否允许 HEIC（及解码依赖）。  
9. 成本上限 / 告警阈值。  
10. 生产启用前是否仍限制 `data_class=test` only。

---

**重申：本文为计划。未执行 `wrangler` 创建资源，未改 Access / 密钥 / 部署。**
