# life-is-data UIUX · 给 Dots 的审阅交接

日期：2026-10-18（Asia/Shanghai）  
发件：Ubuntu 开发（life-远程控制）→ Keith 转发 Dots  
状态：**仅审阅**。未合 main、未部署生产、未改 Access / SIMULATION_MODE / harness。

---

## 1. 看什么

| 项 | 值 |
|---|---|
| 分支 | [`feat/uiux-quick-capture`](https://github.com/keithhegit/life-is-data/tree/feat/uiux-quick-capture) |
| HEAD | `dbf9e3d`（`dbf9e3d91e3c710c3f796a4f39eaa2365b50d757`） |
| 对比 main | https://github.com/keithhegit/life-is-data/compare/main...feat/uiux-quick-capture |
| 基线 main（生产） | `61ac408` |
| 生产 Pages | `922472ab`（**未变**） |
| 生产 Worker | `463f573b`（**未变**；`SIMULATION_MODE=enabled`，旧 harness 关） |

本轮是信息架构重构的 **U1 可点原型**：今日首屏直接记录、记录列表/详情、数据空态、操作员工作台移出日常首页。21st Input Bar / Activity Feed 只作外观参考，已改写成现有 CSS，**未**引入 Tailwind / Next。

本地检查：`cd cloudflare && npm run check` → backend **144/144**，UI **69/69**。

---

## 2. 审阅重点（请优先看）

1. **手机首屏（360/390）**：不滚动能否看到「记下刚刚发生的事」、拍照、上传、保存；底栏「今日 / 记录 / 数据」常显文字。
2. **测试标识**：大黄条已去掉；标题旁「测试模式」徽标 + 输入框下一行小字「测试模式：不会写入真实资料」。是否够清楚，又不抢录入焦点。
3. **时间**：列表/详情是否一律 Asia/Shanghai 短格式（如「昨天 18:10」），无 `…T…Z` 原始 ISO。
4. **详情状态**：有决定时「已选择：每天阅读5分钟」是否只出现一次；当前状态是否来自决定实体，而不是旧分析摘要里的「尚未选择」（UX-09）。
5. **复盘**：`next_options` 是否以「下一步可选项」展示（UX-27）。
6. **工作台**：日常页不应出现领取/租约/提交表单；工作台仍走既有 simulation/operator 能力与服务端鉴权。
7. **文字保存路径**：仍接现有 API（幂等、失败保留草稿）；截图夹具是合成数据，**不代表**已在生产验收完整闭环。
8. **附件**：拍照/上传按钮存在，点按仅提示「附件录入尚未开放」。真上传见 U4 文档，需单独批准存储（R2 等），**本分支未建资源**。

不要把 Pages Preview 部署失败 `8974c215`（源 dbf9e3d）当成产品缺陷；它未成为生产 Active。生产仍是 main。

---

## 3. 相对 main 的主要改动

| 提交 | 内容 |
|---|---|
| `2b5f92f` | 三入口壳 + QuickCapture 首页 + 工作台独立 |
| `cfa6489` | U1 / UX-09 / UX-27 测试 |
| `7718252` | 截图夹具（不进 Pages） |
| `c656548` | U4 附件存储计划（仅文档） |
| `a478758` | 21st 外观改写（无 Tailwind） |
| `a916dbd` | 测试与 eslint 对齐 |
| `dbf9e3d` | 时间格式、已选择去重、测试模式徽标 |

关键文件方向（路径以仓库为准）：`QuickCaptureBar`、`ActivityFeed`、今日/记录/数据壳、`formatTime`、`DecisionReview`（next_options）、工作台入口拆分、`docs/uiux/`、`docs/ops` 下 U4 计划。

---

## 4. 已实现 / 未实现

**已实现**
- 今日 / 记录 / 数据 AppShell；首页 QuickCapture；待处理≤3、最近结果≤2
- 记录紧凑列表 + 详情分节；工作台独立
- UX-09、UX-27；测试模式小标识
- 21st 两组件 CSS 改写；U4 存储变更清单（文档）

**未实现 / 不在本轮发布范围**
- 附件真实上传与私有读取（U4，需批 R2 等）
- 合 main / 生产发布 / 改开关
- Preview 构建修复
- 真机触控、相机、键盘避让实测
- 数据面板真实聚合（当前空态 + 测试模式；`real_data_allowed=false`）

验收清单 UX-01～UX-27 见交接包 `01-开发交接.md` §12；本分支仅声称 U1 可点原型 + 上述两项 bug 修复，**不声称** 27 项全过。

---

## 5. 截图（合成 fixture，不连生产）

同包或同目录 `/workspace/life-is-data-uiux-u1-shots/`：
- `today-360x800.png` / `today-390x844.png` / `today-1440x900.png`
- `detail-390x844.png`（及 360/1440）
- `records-390x844.png`
- `data-390x844.png`（及 360/1440）

---

## 6. 请 Dots 回传

1. 布局与信息架构：通过 / 需改（具体条目）
2. UX-09 / UX-27：是否认可
3. 是否要求修 Preview Failure 后再继续
4. U2/U3 优先级或阻塞项
5. **不要**自行合 main 或改生产开关；发布仍由 Keith 批准

相关文档（Ubuntu box）：
- 本交接：`/workspace/life-is-data-uiux-dots-handoff-20261018.md`
- 原型说明：`/workspace/life-is-data-uiux-u1-prototype-20261018.md`
- U4 存储计划：`/workspace/life-is-data-uiux-u4-storage-plan-20261018.md`
- 设计交接原包：`/workspace/life-is-data-ui-handoff-20261018/life-is-data-uiux-kit-20261018/`
