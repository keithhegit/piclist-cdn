# life-is-data UIUX · U1 可点原型（含三处打磨，已 push 分支）

时间：2026-10-18 约 14:10 Asia/Shanghai。  
分支：**`feat/uiux-quick-capture`**（已 push 远程同名分支，**未合 main、未开 PR、未部署生产、未改开关**）。  
HEAD：**`dbf9e3d91e3c710c3f796a4f39eaa2365b50d757`**（`dbf9e3d`）  
基线 main：仍为 **`61ac408`**。

## 链接（给 Dots）
- 分支：https://github.com/keithhegit/life-is-data/tree/feat/uiux-quick-capture
- Compare：https://github.com/keithhegit/life-is-data/compare/main...feat/uiux-quick-capture

## 提交摘要（相对 61ac408）
| SHA | 说明 |
|---|---|
| `2b5f92f` | U1 壳与 QuickCapture 首页 |
| `cfa6489` | U1 / UX-09 / UX-27 测试 |
| `7718252` | 截图夹具（不进 Pages） |
| `c656548` | U4 附件存储计划（仅文档） |
| `a478758` | 21st 外观改写（无 Tailwind） |
| `a916dbd` | 测试与 eslint 对齐 |
| **`dbf9e3d`** | **打磨：时间显示、已选择去重、测试模式徽标** |

## 本轮三处修复（dbf9e3d）
1. **时间**：`formatDisplayTime`（`web/cloudflare/formatTime.ts`）按 Asia/Shanghai 显示短格式（当天 `HH:mm`、昨天 `昨天 HH:mm`、更早 `M月D日 HH:mm`）。列表/详情统一；截图可见「昨天 18:10」等，无原始 ISO。
2. **已选择去重**：详情页「已选择：每天阅读5分钟」只保留状态摘要一处；分析区不再重复。测试断言 `getAllByText(/已选择：/).length === 1`。
3. **黄条横幅**：去掉首页大块「仅限合成数据…」；标题旁保留「测试模式」小徽标（可点开说明）；完整说明在设置页；输入框下一行小字「测试模式：不会写入真实资料」。UX-17 持续可见测试标识。

## 测试
`cd cloudflare && npm run check`：**backend 144/144**，**UI 69/69**（含 formatTime 与三处打磨用例）。

## 截图（已覆盖 box）
`/workspace/life-is-data-uiux-u1-shots/`（自查：无黄条、时间短格式、详情已选择仅一处）
- today-360x800 / today-390x844 / today-1440x900 / today-390-full
- detail-360 / detail-390 / detail-1440
- records-390x844、data-360 / data-390 / data-1440

## Push 与生产影响
| 项 | 结果 |
|---|---|
| `git push -u origin feat/uiux-quick-capture` | **成功** → `dbf9e3d` |
| Pages **Production** | **未变**：仍为 **`922472ab`**（源 main `61ac408`） |
| Pages Preview | 触发了 Preview 部署 **`8974c215`**（分支 feat/uiux-quick-capture，源 dbf9e3d），状态 **Failure**（未成为生产 Active） |
| Records Worker 100% | **未变**：仍为 **`463f573b`**；`SIMULATION_MODE=ENABLED`，旧 harness 仍 DISABLED |
| 开关 / Access | 未改 |

## 已实现 / 未实现（摘要）
**已实现：** 三入口 AppShell、QuickCapture（真 API 保存路径）、工作台独立、记录列表/详情、UX-09/27、数据空态、21st CSS 改写、三处打磨、截图夹具、U4 计划文档。  
**未实现：** 附件真上传（U4）；合 main / 生产发布；Preview 构建本次失败（不影响审代码）；真机触控/键盘/相机实测。

## 给 Dots 的审阅重点
1. 手机首屏：无黄条；「测试模式」徽标 + 输入框下小字是否够清楚。
2. 时间是否一律短格式（无 `…Z` ISO）。
3. 有决定的详情：状态「已选择：…」是否只出现一次。
4. 导航「今日 / 记录 / 数据」、工作台是否藏在设置/条件入口。
5. 合成数据下文字保存→列表/详情是否仍顺。
6. 不要把 Preview Failure 当成产品缺陷；生产仍是 main `61ac408`。
