# ENVIRONMENT.md — life-is-data 环境清单（按 06 §1）

- **记录时间：** 2026-10-18 15:47–15:55 CST（Asia/Shanghai），HK Ubuntu 只读盘点
- **完整 HEAD SHA：** `dbf9e3d91e3c710c3f796a4f39eaa2365b50d757`（`feat/uiux-quick-capture`）
- **系统架构：** x86_64 Linux（Ubuntu）
- 未导出 env/printenv、shell 配置或用户目录；以下变量只列名称。

## Node

| 证据 | 原文 |
|---|---|
| `.node-version`（已跟踪） | `24.19.0` |
| `.nvmrc` | 不存在 |
| 根 `package.json` engines | `"node": ">=24.19.0 <25"` |
| `cloudflare/package.json` engines | `"node": ">=24.19.0 <25"` |
| CI（`.github/workflows/*`） | 不存在 |

证据之间不冲突。HK 实际 `node --version` = **v24.19.0**（隔离目录 `$HOME/.local/opt/node-v24.19.0-linux-x64/bin`，只在命令里临时加入 PATH）。

## npm

- `packageManager` 字段：两个 package.json 都**没有**；没有 CI 证据。实际使用 npm（存在 package-lock.json）。
- HK 实际 `npm --version` = **11.17.0**（随 Node 24.19.0 自带）。
- `.npmrc`：不存在（没有 registry/认证配置）。`.gitattributes`：不存在。
- 生命周期脚本：两个 package.json 都**没有** `install`/`postinstall`/`prepare` 脚本（依赖自身的原生构建除外，见 Windows 风险）。

## lockfile

| 文件 | lockfileVersion | SHA-256 | 字节 | 与 package.json 匹配 |
|---|---|---|---:|---|
| `package-lock.json` | 3 | `f3aa481bdca4b5f8be31e18b65d8a334d318e6b14c4fa454ab45cb80c6785ac8` | 129796 | 是（HK `npm ci` 安装的树上 check 通过） |
| `cloudflare/package-lock.json` | 3 | `148aadb38e7053b25f79a9017a0136a5edc5457f3b5da3d60191efac38aee4ba` | 90252 | 是（同上） |

两个都要装：`cloudflare` 的 UI 测试和构建会用到根 `node_modules`（react 19.3.0、zod 4.6.7、playwright 等只在根依赖里），`cloudflare/test:e2e` 直接调用 `../node_modules/@playwright/test/cli.js`。

## package.json scripts（逐项原文）

### 根 `package.json`

| script | 原文 |
|---|---|
| build | `tsc -p tsconfig.build.json && node scripts/copy-migrations.mjs && vite build --config vite.contracts.config.ts && vite build` |
| check | `npm run typecheck && npm run lint && npm test && npm run build` |
| lid | `node dist/server/adapters/cli.js` |
| lint | `eslint .` |
| start | `node dist/server/main.js` |
| test | `node --test tests/probes/environment.test.mjs && vitest run` |
| test:acceptance | `vitest run tests/acceptance` |
| test:e2e | `playwright test` |
| typecheck | `tsc --noEmit` |

（根 `npm run check` 跑的是本地 Node 平台大套件，与 Cloudflare UI 交接无关；HK 上运行时间很长、曾卡住，本次没跑。）

### `cloudflare/package.json`

| script | 原文 |
|---|---|
| build:functions | `node scripts/wrangler.mjs pages functions build routing-fixture --outdir dist/functions --output-routes-path dist/functions/_routes.json --output-config-path dist/functions/routes-config.json` |
| build:pages | `vite build --config vite.config.ts && node scripts/build-pages-worker.mjs` |
| build:worker | `node scripts/wrangler.mjs deploy --dry-run --config wrangler.worker.jsonc --env preview --outdir dist/worker/preview && node scripts/wrangler.mjs deploy --dry-run --config wrangler.worker.jsonc --env production --outdir dist/worker/production` |
| check | `npm run typecheck && npm test && npm run test:ui && npm run build:worker && npm run build:pages && npm run build:functions && npm run check:config && npm run check:bundle` |
| check:bundle | `node scripts/check-bundle.mjs` |
| check:config | `node scripts/check-config.mjs` |
| test | `vitest run --config vitest.config.ts` |
| test:e2e | `node ../node_modules/@playwright/test/cli.js test --config playwright.config.ts` |
| test:ui | `vitest run --config vitest.ui.config.ts` |
| typecheck | `tsc --noEmit -p tsconfig.json` |

`cloudflare` 没有 `dev` script。

主要依赖：cloudflare 依赖 jose 6.2.12；开发依赖 wrangler 4.45.0、miniflare 4.20251011.1、@cloudflare/workers-types 4.20251011.0、esbuild 0.28.2、vitest 5.0.4、vite 8.3.4、typescript 5.9.3。根依赖：react/react-dom 19.3.0、zod 4.6.7、better-sqlite3 13.0.3（原生模块）、@simplewebauthn/server、age-encryption、@playwright/test 1.64.0。

## Wrangler

- 本地依赖声明：`cloudflare/package.json` devDependencies `wrangler` = `4.45.0`；lockfile 解析版本 `wrangler@4.45.0`。
- 已跟踪 wrangler 相关文件：`cloudflare/pages/wrangler.jsonc`、`cloudflare/wrangler.worker.jsonc`、`cloudflare/scripts/wrangler.mjs`。
- `scripts/wrangler.mjs` 启动的是**本地** `node_modules/wrangler`，把 `WRANGLER_LOG_PATH` / `XDG_CONFIG_HOME` 设到 `cloudflare/.wrangler` 下，并关闭 metrics；check 里的用法都是 `deploy --dry-run` 或 `pages functions build`，不会部署。
- 不要用裸 `npx wrangler`（可能自动下载其他版本）。
- 注意：两个 wrangler 配置里有已跟踪的 `OWNER_ACTOR_ID` 值（早已在 origin/main 上）。**不要打印、写进日志或贴到聊天里。**

## 变量（只列名称）

| 名称 | 用途 | 必需性 | 接收端如何配置 |
|---|---|---|---|
| `LID_CF_E2E_ORIGIN` | Playwright e2e 目标的受批准 HTTPS origin | 只有 `test:e2e` 需要 | 只有 Keith 授权远端 e2e 后才在当前会话里设置；默认不设、不跑 |
| `LID_CF_E2E_AUTH_STATE` | 可选的 Playwright storageState 路径（Access 会话） | 可选 | 由用户在 Windows 本机自行登录生成；**不迁移** Linux 登录态 |
| `SIMULATION_MODE`、`ANALYSIS_HARNESS`、`DOT_MANUAL_SYNTHETIC`、`OWNER_ACTOR_ID`、`APP_ORIGIN`、`ACCESS_TEAM_DOMAIN`、`ACCESS_AUD`、`OWNER_SUB` | Cloudflare 运行时变量/secret | 只在 Cloudflare 侧需要 | 已在 Cloudflare 配好；本地 check 不需要；**不要**在本地创建或修改 |

仓库没有 `.env.example`，本地 `cloudflare && npm run check` 不需要任何 env 变量。

## 启动

- 没有本地 dev server script。`cloudflare/vite.config.ts` 的 root 是 `../web/cloudflare`，outDir 是 `cloudflare/pages/dist`（由 `build:pages` 生成）。
- UI 截图夹具：`cloudflare/screenshots/`（fixture-api.ts、fixture-main.tsx、screenshots.html、shoot.mjs、vite.config.ts）。`shoot.mjs` 在 `127.0.0.1:4177` 上服务夹具，使用假 API，**不访问远端或生产**。
- 生产/预览都在 Cloudflare 上（Pages + Worker）。访问需要 Cloudflare Access，**不要**用部署代替测试。

## 测试

| 命令 | 前置条件 | 外部写入 |
|---|---|---|
| `cd cloudflare && npm run check` | 根和 cloudflare 都按锁 `npm ci` 过 | 无（vitest + 本地构建 + wrangler dry-run） |
| `cd cloudflare && npm run test:e2e` | `LID_CF_E2E_ORIGIN` + Access 会话 + Playwright 浏览器 | **会访问远端**；没有授权就不跑 |
| 根 `npm run check` | 根依赖（含 better-sqlite3 原生模块） | 本地；与本次交接无关 |

HK 结果见 TEST-EVIDENCE.md（exit 0；backend 18 files/144 tests，UI 9 files/69 tests）。

## Windows 风险

1. **Node 版本**：Win11 全局是 Node v22.12.0，不满足 engines `>=24.19.0 <25`。需要一个隔离的 Node 24.19.0 目录，只在当前 PowerShell 会话改 PATH（见 06 §2）；**下载来源由 Keith 决定**，本包不授权下载。
2. **原生模块**：根依赖 `better-sqlite3` 13.0.3 在 Windows 上需要对应 Node 24 / win-x64 的预编译包，否则要 VS Build Tools 编译；失败就记为阻塞，不要改锁。
3. **Shell 脚本**：`scripts/release-pages.sh` 是 bash 发布脚本，Windows 上不要运行（本次也不授权发布）。
4. **截图夹具路径**：`shoot.mjs` 写死了 `OUT='/tmp/lid-u1-shots'` 和 Linux Chromium 路径 `~/.cache/ms-playwright/chromium-1248/chrome-linux64/chrome`，在 Windows 上会失败；要用的话需要另行改代码（这算新开发，接管后再决定）。
5. **Playwright 浏览器**：不会随 `npm ci` 安装；需要单独安装（会下载，需要授权）。
6. **大小写**：仓库跟踪的是小写 `docs/`；交接文档合并到 `docs\codex-handoff\`，不要新建 `Docs\`。仓库里还有中文文件名（`docs/` 下），Windows Git 正常处理即可。
7. **换行**：没有 `.gitattributes`；Windows Git 的 `core.autocrlf` 可能让工作区显示改动。接收前后用 `git status --short` 对比；不要为此改全局配置。
8. **不要复制** Linux `node_modules`、Playwright 缓存或 `cloudflare/.wrangler` / wrangler 登录态。

## 未核验 / 阻塞

- Windows 上能否装 Node 24.19.0 / better-sqlite3 预编译包：未核验（Windows 未连接）。
- Pages Preview `8974c215` 构建失败：根因未查。
- 远端 e2e：未运行（需要授权和 Access）。
