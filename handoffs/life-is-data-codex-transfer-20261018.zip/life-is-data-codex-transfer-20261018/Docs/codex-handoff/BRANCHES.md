# BRANCHES.md — life-is-data 冻结分支盘点

- **冻结时间：** 2026-10-18 15:47:33 CST（Asia/Shanghai）
- **仓库根：** `/home/ubuntu/workspaces/life-is-data`
- **远程（脱敏）：** `https://github.com/keithhegit/life-is-data`
- **`git fetch origin`：** 2026-10-18 15:47:34 CST（随后补抓 `feat/uiux-quick-capture` 到 `refs/remotes/origin/feat/uiux-quick-capture`）
- **当前检出：** `feat/uiux-quick-capture`（非 detached）
- **工作区：** 干净（无 staged / unstaged / untracked）；**无 stash**

## 完整 SHA

| 引用 | 完整 SHA |
|---|---|
| `origin/main` / 本地 `main` | `61ac40895e8829a8d798d824b5c3554f488503fd` |
| `origin/feat/uiux-quick-capture` | `dbf9e3d91e3c710c3f796a4f39eaa2365b50d757` |
| 本地 `feat/uiux-quick-capture` / HEAD | `dbf9e3d91e3c710c3f796a4f39eaa2365b50d757` |

本地 HEAD **等于** `origin/feat/uiux-quick-capture`（无未推送提交）。相对 `origin/main`：该分支 **ahead 7 / behind 0**。

## 本地分支 vs origin/main

| 分支 | tip（短） | ahead | behind | 说明 |
|---|---|---:|---:|---|
| main | 61ac408 | 0 | 0 | 与 origin/main 同步 |
| feat/uiux-quick-capture | dbf9e3d | 7 | 0 | **交接分支** |
| feat/mobile-first-ui-pwa | 1e7e8ea | 2 | 26 | 未合入；勿整支合并 |
| feat/user-simulation-v1 | 29a6b3a | 0 | 3 | 已合入 main |
| fix/sim-batch-start | 1cc7c99 | 0 | 1 | 已合入 main |
| feat/g1-* / fix/g1-* / light-capture / backup-restore | （旧） | 0 | 多 | 已合入或落后 |

## 远端分支

| 分支 | tip | ahead of main | behind |
|---|---|---:|---:|
| origin/main | 61ac408 | 0 | 0 |
| origin/feat/uiux-quick-capture | dbf9e3d | 7 | 0 |
| origin/feat/cloudflare-v1 | ded4962 | 0 | 35 | 旧 |

## docs 大小写

- 仓库跟踪 **小写 `docs/`**（约 29–33 个已跟踪路径，含 `docs/ops/`、`docs/uiux/` 等）。
- **无** 已跟踪的大写 `Docs/`。
- Windows 接收时应合入 `docs/codex-handoff/`，不要另建仅大小写不同的 `Docs/`。

## 生产只读快照（冻结时）

| 资源 | 值 |
|---|---|
| Pages Production | `922472ab-213d-4071-a539-c25dfc371eda`（源 main `61ac408`） |
| Pages Preview（feat 分支） | `8974c215-d936-49ea-b10b-f11c9e2d276f` — **Failure**（未查日志） |
| Worker 100% | `463f573b-1d47-4e4a-9862-7bac7ed811b1` |
| Worker `SIMULATION_MODE` | ENABLED |
| Worker `ANALYSIS_HARNESS` / `DOT_MANUAL_SYNTHETIC` | DISABLED |
| Pages secrets | 仅有 `SIMULATION_MODE`（encrypted）；旧 harness secrets 已删除 |
