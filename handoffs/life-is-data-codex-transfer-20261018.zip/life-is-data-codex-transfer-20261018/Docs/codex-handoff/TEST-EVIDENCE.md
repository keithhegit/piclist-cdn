# TEST-EVIDENCE.md

机器：HK Ubuntu `ubuntu@14.136.93.106`（x86_64 Linux）  
冻结交接验证（非新功能开发）

## 交接 SHA 上的 `npm run check`

| 项 | 值 |
|---|---|
| 时间 | 开始 2026-10-18 15:48:26 CST → 结束 15:50:53 CST |
| 分支 / SHA | `feat/uiux-quick-capture` / `dbf9e3d91e3c710c3f796a4f39eaa2365b50d757` |
| 命令 | `cd cloudflare && npm run check` |
| PATH | `$HOME/.local/opt/node-v24.19.0-linux-x64/bin` + `$HOME/.local/bin` |
| Node / npm | v24.19.0 / 11.17.0 |
| 退出码 | **0** |
| Backend | Test Files **18** passed；Tests **144** passed |
| UI | Test Files **9** passed；Tests **69** passed |
| 其余 | typecheck、build:worker、build:pages、build:functions、check:config、check:bundle 均含于 check 且整体成功 |
| 日志 | HK `/tmp/lid-handoff-check.out`（未随包带走；无密钥） |
| 是否触达生产 / 外部写入 | **否**（本地 vitest / 构建 dry-run） |

## 未运行

- `cloudflare` 的 `test:e2e`（Playwright）：需要 `LID_CF_E2E_ORIGIN` 与 Access 会话；**故意不跑**触达生产的 e2e。
- 仓库根目录 `npm run check`：会跑本地 Node 平台大套件，与 Cloudflare UI 交接无关；**未跑**。
- Preview 部署 `8974c215` 失败原因：**未查**。

## 历史证据（引用，非本轮重跑）

- U1 原型打磨后 UI 69、backend 144（与本轮复跑一致）。
- Gate A / 模拟矩阵状态见包内 `03-测试进度与未完成矩阵.md` 与 `references/`。
