# life-is-data → 本地 clean-context Codex

这是 dot 整理的**上下文、开发要求与验收证据包**，不是最新源码，也不表示文件已写到你的 Win11。

最终工作目录：`D:\Codex_workspace\life-is-data`  
最终文档目录：`D:\Codex_workspace\life-is-data\Docs\codex-handoff`

仓库如果已跟踪小写`docs`，Windows默认大小写不敏感，可从`Docs`访问；保留仓库既有大小写，不并建两个目录，不做无必要的大小写重命名。

先把本包放在仓库外的接收暂存目录。先确立/同步正确代码根，再把文档合入`Docs/codex-handoff`；不要先向待clone的空目录放Docs，否则clone会因目录非空失败。已有文件不覆盖、不删除，先核对差异。

## 先把整包给Ubuntu

Ubuntu负责补齐最新仓库状态、源码交付与本机验证后的环境清单；本地Codex负责核验Windows旧目录、保全旧改动并接收。只有Ubuntu确实有已获授权的Windows写入通道时才由它直接落盘，否则请它输出完整传输包，由本地Codex落盘，不能假称写入成功。

请Ubuntu：

1. 暂停新功能改动；核对所有分支、工作区、未提交/未推送内容与当前生产版本，交出可追溯快照。不要合main、部署或修改安全开关。
2. 读`Docs/codex-handoff/05-Ubuntu交出与Windows接收.md`与`06-环境清单与启动核验.md`，补齐environment/branches/unfinished/test-evidence/transfer-manifest五项清单。
3. 把此包的Docs与最新代码快照一起交接；不得把旧main冒充含UI分支的最新开发状态。未提交工作要有去向，不能遗漏，也不能夹带密钥。
4. 明确Node/npm/锁文件/Wrangler/测试脚本实值，提供Windows适配步骤。不要把Linux node_modules、登录态、token或实际私人数据复制过去。
5. 接收方核验SHA与文件清单后，确认由本地Codex单一负责代码写入；Ubuntu随后只提供审查/环境支持，除非Keith另行指定。

## 新Codex启动提示词（整段复制）

你现在接手life-is-data。我的本地工作目录是D:\Codex_workspace\life-is-data，交接文档在Docs\codex-handoff。先读00-START-HERE.md及其阅读顺序，再检查本地Git根、分支、未提交改动和Ubuntu提供的最新快照。当前本地代码可能过时，禁止直接reset、clean或覆盖。核实所有未提交/未推送工作已保全，确认目标分支/完整SHA后再同步。仓库已有docs时保留其实际大小写，不新增重复Docs目录。

不要重新推倒产品方案，不要把TEST数据当我的真实记录，也不要重复创建已完成的GUI-01决定/结果/复盘。先报告接收核验结果、已跑和未跑的测试及下一步，再按最新UI审阅R1–R4推进。WebApp轻量录入与查阅，dot负责分析，不新增provider。用户端不要开发长说明、不可用假按钮或测试控制台。现有数据、鉴权、幂等、版本引用必须保留。未经我的单独批准，不合main、不部署、不改模式/Access、不建CF资源、不删除测试数据。

## 交接完成的判断

不是“文件发了”就完成，而是新Codex能在目标目录识别正确Git根与SHA、读完交接、使用隔离Node环境按锁文件安装、完成构建/约定检查、打开本地UI，并回传接收回执；缺少任何条件则明确标注，不虚称已接管完成。
